#pylint:disable=E1101
import xbmcgui
import xbmcaddon
import color
import variables as var

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

class MessageDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.message = kwargs.get('message', '')

    def onInit(self):
        header = self.getControl(1001)
        header.setText(color.star_wrap(color.cyan(f'{var.addon_name} version: {var.addon_version}')))
        textbox = self.getControl(1000)
        textbox.setText(self.message)

    def onAction(self, action):
        if action in (9, 10, 7, 100, 92):  # Backspace, Escape, Select, Left Click, Back
            self.close()

# Run the dialog
def show_message(message):
    dialog = MessageDialog('message.xml', ADDON_PATH, 'default', '1080i', message=message)
    dialog.doModal()
    del dialog
    