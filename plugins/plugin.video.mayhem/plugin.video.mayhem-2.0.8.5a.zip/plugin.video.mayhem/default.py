import xbmcgui
import xbmc
import base64
import xbmcaddon
import xbmcvfs
import os
import traceback
import xml.etree.ElementTree as ET

from typing import Optional, List, Any

EXPECTED_ID = "plugin.video.mayhem"
ADDON = xbmcaddon.Addon()
ACTUAL_ID = ADDON.getAddonInfo("id")

# Define multiple repository URLs
REQUIRED_REPO_URLS = [
    "https://mfirepo.github.io/mfirepo",  
    "http://mfirepo.github.io/mfirepo",  
    "https://tinyurl.com/neorepo",  
    "http://tinyurl.com/neorepo",  
    #"https://gitlab.com/madforit/repository/-/raw/main/repo.zip",  
    #"https://your-repo-url.com/repo.zip"  
]

REQUIRED_REPO_NAME = "Mad For It Repo"

if ACTUAL_ID != EXPECTED_ID:
    xbmcgui.Dialog().ok("Error", "Addon ID Mismatch!")
    raise SystemExit(1)
else:
    xbmc.log(f"[Mayhem] Addon ID verified: {ACTUAL_ID}", xbmc.LOGINFO)

def check_repo_url_in_sources():
    """
    Check if any of the repository URLs are configured in Kodi's file manager sources.
    Returns the found URL if successful, False otherwise.
    """
    sources_xml_path = xbmcvfs.translatePath("special://home/userdata/sources.xml")
    
    # Check if sources.xml exists
    if not xbmcvfs.exists(sources_xml_path):
        xbmc.log(f"[Mayhem] sources.xml not found at: {sources_xml_path}", xbmc.LOGERROR)
        return False
    
    try:
        # Read and parse the sources.xml file
        with xbmcvfs.File(sources_xml_path, 'r') as f:
            xml_content = f.read()
        
        if not xml_content:
            xbmc.log("[Mayhem] sources.xml is empty", xbmc.LOGERROR)
            return False
            
        root = ET.fromstring(xml_content)
        
        # Look for any of the repository URLs in all path elements
        for path in root.findall(".//path"):
            if path.text:
                for repo_url in REQUIRED_REPO_URLS:
                    if repo_url in path.text:
                        xbmc.log(f"[Mayhem] Repository URL found in file manager: {repo_url}", xbmc.LOGINFO)
                        return repo_url
        
        # Also check for URLs in any network source
        for source in root.findall(".//source"):
            for path in source.findall("path"):
                if path.text:
                    for repo_url in REQUIRED_REPO_URLS:
                        if repo_url in path.text:
                            xbmc.log(f"[Mayhem] Repository URL found in file manager: {repo_url}", xbmc.LOGINFO)
                            return repo_url
                    
        # Check for repository name patterns in source names
        for source in root.findall(".//source"):
            for name in source.findall("name"):
                if name.text and ("mad" in name.text.lower() or "repo" in name.text.lower() or "repository" in name.text.lower()):
                    for path in source.findall("path"):
                        if path.text and any(url_part in path.text for url_part in ["http", "https", "zip"]):
                            xbmc.log(f"[Mayhem] Potential repository source found: {name.text} - {path.text}", xbmc.LOGINFO)
                            return path.text
                    
    except Exception as e:
        xbmc.log(f"[Mayhem] Error parsing sources.xml: {e}", xbmc.LOGERROR)
        xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
    
    return False

# Check for any required repository URL in file manager before proceeding
found_repo_url = check_repo_url_in_sources()
if not found_repo_url:
    # Show notification to user with installation instructions
    message = f"{REQUIRED_REPO_NAME} source is required to run this addon.\n\nPlease add one of these URLs to your file manager sources:"
    
    # Create a formatted list of URLs for display
    url_list = "\n".join([f"• {url}" for url in REQUIRED_REPO_URLS])
    full_message = f"{message}\n\n{url_list}"
    
    xbmcgui.Dialog().ok("Repository Source Required", full_message)
    
    # Offer to show instructions for adding the source
    if xbmcgui.Dialog().yesno("Add Source", "Would you like to see instructions for adding the source to file manager?"):
        instructions = (
            "1. Go to Settings > File Manager\n"
            "2. Select 'Add source'\n"
            "3. Enter one of the URLs shown above\n"
            "4. Name it 'Mad For It Repo' or similar\n"
            "5. Click OK to save\n"
            "6. Restart this addon after adding the source"
        )
        xbmcgui.Dialog().ok("Instructions", instructions)
    
    raise SystemExit(1)
else:
    xbmc.log(f"[Mayhem] Using repository URL: {found_repo_url}", xbmc.LOGINFO)

# Import local modules with better error handling
try:
    from resources.lib.DI import DI
    from resources.lib.plugin import run_hook, register_routes
    from resources.lib.util.common import *
except ImportError:
    try:
        from .resources.lib.DI import DI
        from .resources.lib.plugin import run_hook, register_routes
        from .resources.lib.util.common import *
    except ImportError as e:
        xbmc.log(f"[Mayhem] Failed to import required modules: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Import Error", "Failed to load required components.")
        raise SystemExit(1)

ROOT_XML_URL = "https://bitbucket.org/halcyonhal/halcyon2/raw/main/may.json"

SHORT_CHECKER = {
    'Adf.ly', 'Bit.ly', 'Chilp.it', 'Clck.ru', 'Cutt.ly', 'Da.gd', 'Git.io', 
    'goo.gl', 'Is.gd', 'NullPointer', 'Os.db', 'Ow.ly', 'Po.st', 'Qps.ru', 
    'Short.cm', 'Tiny.cc', 'TinyURL.com'
}

plugin = DI.plugin

def log(msg: str, level=xbmc.LOGINFO):
    """Log message with addon prefix."""
    xbmc.log(f"[Mayhem] {msg}", level)

def is_short_url(url: str) -> bool:
    """Check if URL is from a known shortener service."""
    return any(shortener.lower() in url.lower() for shortener in SHORT_CHECKER)

@plugin.route("/")
def root() -> None:
    """Root route: Load default list."""
    get_list(ROOT_XML_URL)

@plugin.route("/get_list/<path:url>")
def get_list(url: str) -> None:
    """Route handler to fetch list content from given URL."""
    # Normalize URL - replace .xmll with .xml if present
    if url.endswith('.xmll'):
        url = url[:-1]  # Remove the extra 'l'
    
    _get_list(url)

def _get_list(url: str) -> None:
    """Fetch, parse, and display a content list."""
    try:
        # Resolve short URLs if needed
        if is_short_url(url):
            response = DI.session.get(url, allow_redirects=True)
            url = response.url
        
        # Check cache first if enabled
        use_cache = ADDON.getSettingBool("use_cache")
        cached_response = None
        
        if use_cache and "tmdb/search" not in url:
            cached_response = DI.db.get(url)
        
        if cached_response:
            response = cached_response
            log(f"Using cached response for {url}")
        else:
            response = run_hook("get_list", url)
            if response and use_cache and "tmdb/search" not in url:
                DI.db.set(url, response)
        
        if response:
            # Parse and process the list
            jen_list = run_hook("parse_list", url, response)
            if not jen_list:
                jen_list = []
            
            # Process each item
            processed_items = []
            for item in jen_list:
                try:
                    processed_item = run_hook("process_item", item)
                    processed_item = run_hook("get_metadata", processed_item, return_item_on_failure=True)
                    processed_items.append(processed_item)
                except Exception as e:
                    log(f"Error processing item {item}: {e}", xbmc.LOGERROR)
                    continue
            
            run_hook("display_list", processed_items)
        else:
            log(f"Empty response for URL: {url}", xbmc.LOGWARNING)
            run_hook("display_list", [])
            xbmcgui.Dialog().notification("Mayhem", "No content available", xbmcgui.NOTIFICATION_WARNING)

    except Exception as e:
        log(f"Error getting list from {url}: {e}", xbmc.LOGERROR)
        log(traceback.format_exc(), xbmc.LOGDEBUG)
        xbmcgui.Dialog().notification("Mayhem", "Failed to load list", xbmcgui.NOTIFICATION_ERROR)

@plugin.route("/play_video/<path:video>")
def play_video(video: str) -> None:
    """Route handler to decode and play a video."""
    _play_video(video)

def _play_video(video: str) -> None:
    """Decode and play video via hook."""
    try:
        # Try to decode as base64 first
        try:
            video_data = base64.urlsafe_b64decode(video + '===').decode('utf-8')
            if '"link":' in video_data:
                video_link = run_hook("pre_play", video_data)
                if video_link:
                    run_hook("play_video", video_link)
                    return
        except (binascii.Error, UnicodeDecodeError):
            # Not base64 encoded, treat as direct URL
            video_data = video
        
        # Fallback to direct play
        run_hook("play_video", video_data)
        
    except Exception as e:
        log(f"Error playing video: {e}", xbmc.LOGERROR)
        log(traceback.format_exc(), xbmc.LOGDEBUG)
        xbmcgui.Dialog().notification("Playback Error", "Could not play video", xbmcgui.NOTIFICATION_ERROR)

@plugin.route("/settings")
def settings() -> None:
    """Open addon settings window."""
    ADDON.openSettings()

@plugin.route("/clear_cache")
def clear_cache() -> None:
    """Clear local database cache."""
    DI.db.clear_cache()
    xbmcgui.Dialog().notification("Cache Cleared", "All cached data has been removed", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def main():
    """Main entry point for the addon."""
    try:
        register_routes(plugin)
        plugin.run()
    except Exception as e:
        log(f"Fatal error in main: {e}", xbmc.LOGERROR)
        log(traceback.format_exc(), xbmc.LOGDEBUG)
        xbmcgui.Dialog().ok("Fatal Error", "The addon encountered a critical error and must close.")

if __name__ == "__main__":
    main()
