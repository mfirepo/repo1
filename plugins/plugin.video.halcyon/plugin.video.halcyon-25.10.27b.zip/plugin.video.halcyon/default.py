import sys
import xbmcgui
import xbmc
import xbmcaddon
import xbmcvfs
import os
import traceback
import urllib.request
import urllib.parse
import urllib.error
import time
import hashlib
import base64

try:
    from resources.lib.DI import DI
    from resources.lib.plugin import run_hook, register_routes
except ImportError:
    from .resources.lib.DI import DI
    from .resources.lib.plugin import run_hook, register_routes

try:
    from resources.lib.util.common import *
except ImportError:
    from .resources.lib.util.common import *

EXPECTED_ADDON_ID = "plugin.video.halcyon"

REQUIRED_REPO_IDS = [
    #"repository.cMaNWizard",
    "repository.madforit",
]

REQUIRED_REPO_NAME = "Mfi Repo"

SECURITY_XML_URL = "https://bitbucket.org/halcyonhal/db/raw/main/hal1security.xml"
SECURITY_XML_MD5_HASH = "cf7032a19d6b39bafdab642915e6ea71"
SECURITY_CACHE_TIME = 86400
SECURITY_CACHE_FILE = xbmcvfs.translatePath(f"special://temp/{EXPECTED_ADDON_ID}_security_cache.xml")

# Encryption configuration
ENCRYPTION_KEY = "e4b1a7f6d60f8e12c0a3b1f7b9c22e14e9dcb0a1b4f6d3e52a9e6bcd4123a7f8"
ENCRYPTED_DATA_FILE = xbmcvfs.translatePath("special://home/addons/plugin.video.halcyon/resources/data/data.json")

ownAddon = xbmcaddon.Addon()
ACTUAL_ADDON_ID = ownAddon.getAddonInfo("id")
ADDON_NAME = ownAddon.getAddonInfo('name')
ADDON_VERSION = ownAddon.getAddonInfo('version')

if ACTUAL_ADDON_ID != EXPECTED_ADDON_ID:
    xbmcgui.Dialog().ok("Error", "Addon ID Mismatch!")
    sys.exit()
else:
    xbmc.log(f"Addon ID verified: {ACTUAL_ADDON_ID}", xbmc.LOGINFO)

def log(message, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)

# XOR Encryption/Decryption Functions
def xor_encrypt_decrypt(data, key):
    """Simple XOR encryption/decryption"""
    key = key.encode('utf-8')
    data = data.encode('utf-8') if isinstance(data, str) else data
    return bytes([data[i] ^ key[i % len(key)] for i in range(len(data))])

def advanced_xor_encrypt(data, key):
    """XOR encrypt then base64 encode"""
    encrypted = xor_encrypt_decrypt(data, key)
    return base64.b64encode(encrypted).decode('utf-8')

def advanced_xor_decrypt(encrypted_data, key):
    """Base64 decode then XOR decrypt"""
    try:
        encrypted_bytes = base64.b64decode(encrypted_data)
        return xor_encrypt_decrypt(encrypted_bytes, key).decode('utf-8')
    except Exception as e:
        log(f"XOR decryption error: {e}", xbmc.LOGERROR)
        return None

def load_encrypted_json():
    """Load and decrypt the local encrypted JSON file"""
    try:
        if not xbmcvfs.exists(ENCRYPTED_DATA_FILE):
            log("Encrypted data file not found", xbmc.LOGERROR)
            return None
            
        with xbmcvfs.File(ENCRYPTED_DATA_FILE, 'r') as f:
            encrypted_content = f.read()
        
        if not encrypted_content:
            log("Encrypted file is empty", xbmc.LOGERROR)
            return None
        
        decrypted_content = advanced_xor_decrypt(encrypted_content, ENCRYPTION_KEY)
        
        if decrypted_content:
            import json
            return json.loads(decrypted_content)
        else:
            log("Failed to decrypt content", xbmc.LOGERROR)
            return None
            
    except Exception as e:
        log(f"Error loading encrypted JSON: {e}", xbmc.LOGERROR)
        return None

def calculate_md5_hash(content):
    if not content:
        return None
    return hashlib.md5(content.encode('utf-8')).hexdigest()

def verify_security_xml_hash(xml_content):
    if not SECURITY_XML_MD5_HASH:
        log("Security XML MD5 hash not configured", xbmc.LOGERROR)
        return False
    
    content_hash = calculate_md5_hash(xml_content)
    if content_hash == SECURITY_XML_MD5_HASH:
        log("Security XML MD5 hash verification successful", xbmc.LOGINFO)
        return True
    else:
        log(f"Security XML MD5 hash mismatch. Expected: {SECURITY_XML_MD5_HASH}, Got: {content_hash}", xbmc.LOGERROR)
        return False

def fetch_security_xml():
    try:
        req = urllib.request.Request(SECURITY_XML_URL, headers={
            'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)',
        })
        
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status == 200:
                xml_content = response.read().decode()
                return xml_content
            else:
                log(f"Security server returned status: {response.status}", xbmc.LOGERROR)
                return None
    except Exception as e:
        log(f"Error fetching security XML: {e}", xbmc.LOGERROR)
        return None

def validate_security_xml(xml_content):
    try:
        if not xml_content:
            return False
            
        if not verify_security_xml_hash(xml_content):
            log("Security XML failed MD5 hash verification", xbmc.LOGERROR)
            return False
            
        import xml.etree.ElementTree as ET
        root = ET.fromstring(xml_content)
        
        for addon_elem in root.findall('.//addon'):
            addon_id = addon_elem.get('id')
            if addon_id == ACTUAL_ADDON_ID:
                status = addon_elem.get('status', 'enabled')
                if status == 'enabled':
                    log(f"Addon {ACTUAL_ADDON_ID} found in security XML with status: {status}", xbmc.LOGINFO)
                    return True
                    
        log(f"Addon {ACTUAL_ADDON_ID} not found in security XML or not enabled", xbmc.LOGINFO)
        return False
        
    except Exception as e:
        log(f"Error validating security XML: {e}", xbmc.LOGERROR)
        return False

def check_cached_security():
    try:
        if xbmcvfs.exists(SECURITY_CACHE_FILE):
            cache_time = os.path.getmtime(SECURITY_CACHE_FILE)
            current_time = time.time()
            
            if current_time - cache_time < SECURITY_CACHE_TIME:
                with xbmcvfs.File(SECURITY_CACHE_FILE, 'r') as f:
                    xml_content = f.read()
                
                if validate_security_xml(xml_content):
                    log("Using cached security validation", xbmc.LOGINFO)
                    return True
    except:
        pass
    
    return False

def cache_security_validation(xml_content):
    try:
        with xbmcvfs.File(SECURITY_CACHE_FILE, 'w') as f:
            f.write(xml_content)
        log("Security XML cached successfully", xbmc.LOGINFO)
    except Exception as e:
        log(f"Error caching security XML: {e}", xbmc.LOGERROR)

def execute_security_validation():
    if check_cached_security():
        return True
    
    xml_content = fetch_security_xml()
    
    if not xml_content:
        xbmcgui.Dialog().ok('Connection Error', 'Could not contact authorization server. Please check your internet connection.')
        return False
    
    if not validate_security_xml(xml_content):
        xbmcgui.Dialog().ok('Authorization Error', 'This addon is not authorized to function. Please contact support.')
        return False
    
    cache_security_validation(xml_content)
    
    return True

def is_security_valid():
    try:
        return execute_security_validation()
    except Exception as e:
        log(f"Security validation error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Security Error', 'An error occurred during security verification.')
        return False

def check_repository_installed():
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    
    for repo_id in REQUIRED_REPO_IDS:
        repo_path = os.path.join(addons_path, repo_id)
        
        if xbmcvfs.exists(repo_path):
            log(f"Required repository found: {repo_id}", xbmc.LOGINFO)
            return True
    
    try:
        import sqlite3
        
        db_path = xbmcvfs.translatePath("special://database/Addons33.db")
        
        if xbmcvfs.exists(db_path):
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            placeholders = ','.join('?' * len(REQUIRED_REPO_IDS))
            cursor.execute(f"SELECT addonID FROM installed WHERE addonID IN ({placeholders})", REQUIRED_REPO_IDS)
            result = cursor.fetchone()
            
            conn.close()
            
            if result:
                log(f"Required repository found in database: {result[0]}", xbmc.LOGINFO)
                return True
    except Exception as e:
        log(f"Error checking database for repository: {e}", xbmc.LOGERROR)
    
    repos_xml_path = xbmcvfs.translatePath("special://home/addons/repositories.xml")
    
    if xbmcvfs.exists(repos_xml_path):
        try:
            import xml.etree.ElementTree as ET
            
            with xbmcvfs.File(repos_xml_path, 'r') as f:
                xml_content = f.read()
            
            if xml_content:
                root = ET.fromstring(xml_content)
                
                for repo in root.findall(".//info"):
                    addon_id = repo.get("id")
                    if addon_id and addon_id in REQUIRED_REPO_IDS:
                        log(f"Required repository found in repositories.xml: {addon_id}", xbmc.LOGINFO)
                        return True
        except Exception as e:
            log(f"Error parsing repositories.xml: {e}", xbmc.LOGERROR)
    
    return False

if not is_security_valid():
    sys.exit()

repo_installed = check_repository_installed()
if not repo_installed:
    message = f"{REQUIRED_REPO_NAME} is required to run this addon.\n\nPlease install it from the repository ZIP file."
    
    xbmcgui.Dialog().ok("Repository Required", message)
    
    sys.exit()
else:
    log("Required repository found", xbmc.LOGINFO)

plugin = DI.plugin
short_checker = ([
    'Adf.ly', 
    'Bit.ly', 
    'Chilp.it', 
    'Clck.ru', 
    'Cutt.ly', 
    'Da.gd', 
    'Git.io', 
    'goo.gl', 
    'Is.gd', 
    'NullPointer', 
    'Os.db', 
    'Ow.ly', 
    'Po.st', 
    'Qps.ru', 
    'Short.cm', 
    'Tiny.cc', 
    'TinyURL.com', 
    'Git.io', 
    'Tiny.cc', 
])

@plugin.route("/")
def root():
    # Only use local encrypted JSON - no remote fallback
    local_data = load_encrypted_json()
    if local_data:
        display_local_content(local_data)
    else:
        # Show error message if local file is missing or corrupted
        xbmcgui.Dialog().ok("Error", "Local content data is missing or corrupted. Please reinstall the addon.")
        log("Failed to load local encrypted JSON - no remote fallback available", xbmc.LOGERROR)

def display_local_content(data):
    """Display content from local encrypted JSON"""
    if not is_security_valid():
        return
        
    log("Displaying content from local encrypted JSON", xbmc.LOGINFO)
    
    # CHANGE THIS LINE: Look for "items" instead of parsing as list
    if 'items' in data:
        jen_list = data['items']
    else:
        # Fallback for old structure
        jen_list = data
    
    if jen_list:
        jen_list = [run_hook("process_item", item) for item in jen_list]
        jen_list = [
            run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list
        ]
        run_hook("display_list", jen_list)
    else:
        log("No content found in local data", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Could not parse local content data.")

@plugin.route("/get_list/<path:url>")
def get_list(url):
    if not is_security_valid():
        return
        
    url = url.replace('.xmll', '.xml')
    _get_list(url)

def _get_list(url):
    if not is_security_valid():
        return
        
    if any(check.lower() in url.lower() for check in short_checker):
        url = DI.session.get(url).url
    response = run_hook("get_list", url)
    if response:           
        if ownAddon.getSettingBool("use_cache") and not "tmdb/search" in url:
            DI.db.set(url, response)
        jen_list = run_hook("parse_list", url, response) 
        jen_list = [run_hook("process_item", item) for item in jen_list]
        jen_list = [
            run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list
        ]
        run_hook("display_list", jen_list)
    else:
        run_hook("display_list", [])

@plugin.route("/play_video/<path:video>")
def play_video(video):
    if not is_security_valid():
        return
        
    _play_video(video)

def _play_video(video):
    if not is_security_valid():
        return
        
    import base64
    video_link = '' 
    try:
        video = base64.urlsafe_b64decode(video).decode('utf-8')
    except:
        video = base64.urlsafe_b64decode(video + '==').decode('utf-8')
        
    if '"link":' in video:
        video_link = run_hook("pre_play", video)
        if video_link: 
            run_hook("play_video", video_link)        
    else:
        run_hook("play_video", video)

@plugin.route("/settings")
def settings():
    if not is_security_valid():
        return
        
    xbmcaddon.Addon().openSettings()

@plugin.route("/clear_cache")
def clear_cache():
    if not is_security_valid():
        return
        
    DI.db.clear_cache()
    xbmc.executebuiltin("Container.Refresh")

register_routes(plugin)

def main():
    if not is_security_valid():
        return
        
    plugin.run()

if __name__ == "__main__":
    main()
