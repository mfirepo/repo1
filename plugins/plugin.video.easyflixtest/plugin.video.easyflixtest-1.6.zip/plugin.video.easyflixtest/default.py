import sys
import json
import urllib.request
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Constants
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()
REMOTE_JSON = "https://cmanbuildsxyz.com/forkq/vod.json"  # Change this to your remote JSON URL

def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"

def fetch_remote_json(url):
    try:
        with urllib.request.urlopen(url) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        xbmc.log(f"Error fetching JSON: {e}", xbmc.LOGERROR)
        return []

def list_videos():
    items = fetch_remote_json(REMOTE_JSON)
    for item in items:
        list_item = xbmcgui.ListItem(label=item['title'])
        list_item.setArt({
            'thumbnail': item.get('thumbnail', ''),
            'fanart': item.get('fanart', ''),
            'icon': item.get('thumbnail', '')
        })
        url = get_url(action='play', video_url=item['url'])
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(video_url):
    import resolveurl
    resolved = resolveurl.resolve(video_url)
    if resolved:
        xbmc.Player().play(resolved)
    else:
        xbmcgui.Dialog().notification("ResolveURL", "Failed to resolve URL", xbmcgui.NOTIFICATION_ERROR)

def router(params):
    action = params.get('action')
    if action == 'play':
        play_video(params['video_url'])
    else:
        list_videos()

if __name__ == '__main__':
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    params = {k: v[0] for k, v in args.items()}
    router(params)
