import xbmcgui
import xbmc
import base64
import xbmcaddon

from typing import Optional

EXPECTED_ID = "plugin.video.forkq"
ADDON = xbmcaddon.Addon()
ACTUAL_ID = ADDON.getAddonInfo("id")

if ACTUAL_ID != EXPECTED_ID:
    xbmcgui.Dialog().ok("Error", "Addon ID Mismatch!")
    raise SystemExit
else:
    xbmc.log(f"[Mayhem] Addon ID verified: {ACTUAL_ID}", xbmc.LOGINFO)

try:
    from resources.lib.DI import DI
    from resources.lib.plugin import run_hook, register_routes
except ImportError:
    from .resources.lib.DI import DI
    from .resources.lib.plugin import run_hook, register_routes

try:
    from resources.lib.util.common import *
except ImportError:
    from .resources.lib.util.common import *

ROOT_XML_URL = "https://bitbucket.org/halcyonhal/4q/raw/main/main.json"

SHORT_CHECKER = list(set([
    'Adf.ly', 'Bit.ly', 'Chilp.it', 'Clck.ru', 'Cutt.ly', 'Da.gd', 'Git.io', 
    'goo.gl', 'Is.gd', 'NullPointer', 'Os.db', 'Ow.ly', 'Po.st', 'Qps.ru', 
    'Short.cm', 'Tiny.cc', 'TinyURL.com'
]))

plugin = DI.plugin

def log(msg: str, level=xbmc.LOGINFO):
    xbmc.log(f"[Mayhem] {msg}", level)

@plugin.route("/")
def root() -> None:
    """Root route: Load default list."""
    get_list(ROOT_XML_URL)

@plugin.route("/get_list/<path:url>")
def get_list(url: str) -> None:
    """Route handler to fetch list content from given URL."""
    url = url.replace('.xmll', '.xml')
    _get_list(url)

def _get_list(url: str) -> None:
    """Fetch, parse, and display a content list."""
    try:
        if any(check.lower() in url.lower() for check in SHORT_CHECKER):
            response = DI.session.get(url)
            url = response.url
        response = run_hook("get_list", url)

        if response:
            try:
                use_cache = xbmcaddon.Addon().getSettingBool("use_cache")
            except Exception:
                use_cache = False

            if use_cache and "tmdb/search" not in url:
                DI.db.set(url, response)

            jen_list = run_hook("parse_list", url, response)
            jen_list = [run_hook("process_item", item) for item in jen_list]
            jen_list = [
                run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list
            ]
            run_hook("display_list", jen_list)
        else:
            run_hook("display_list", [])

    except Exception as e:
        log(f"Error getting list: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Mayhem", "Failed to load list.", xbmcgui.NOTIFICATION_ERROR)

@plugin.route("/play_video/<path:video>")
def play_video(video: str) -> None:
    """Route handler to decode and play a video."""
    _play_video(video)

def _play_video(video: str) -> None:
    """Decode base64 and play video via hook."""
    try:
        video_data = base64.urlsafe_b64decode(video)
        if b'"link":' in video_data:
            video_link = run_hook("pre_play", video_data)
            if video_link:
                run_hook("play_video", video_link)
        else:
            run_hook("play_video", video_data)
    except Exception as e:
        log(f"Error playing video: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Playback Error", "Invalid video link.", xbmcgui.NOTIFICATION_ERROR)

@plugin.route("/settings")
def settings() -> None:
    """Open addon settings window."""
    xbmcaddon.Addon().openSettings()

@plugin.route("/clear_cache")
def clear_cache() -> None:
    """Clear local database cache."""
    DI.db.clear_cache()
    xbmc.executebuiltin("Container.Refresh")

register_routes(plugin)

if __name__ == "__main__":
    plugin.run()

