import sys
import urllib.parse
import xbmcplugin
import xbmc
from router import Router

def main():
    """
    Main entry point for Kodi addon
    Handles parameter parsing and routing
    """
    try:
        # Parse parameters safely
        params = {}
        if len(sys.argv) > 2 and sys.argv[2]:
            params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        
        # Log for debugging
        xbmc.log(f"{sys.argv[0]} called with handle {sys.argv[1]} and params: {params}", xbmc.LOGDEBUG)
        
        # Route the request
        router = Router()
        router.route(params)
        
    except Exception as e:
        xbmc.log(f"Fatal error in main: {str(e)}", xbmc.LOGERROR)
        # Ensure Kodi doesn't hang on error
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

if __name__ == '__main__':
    main()
