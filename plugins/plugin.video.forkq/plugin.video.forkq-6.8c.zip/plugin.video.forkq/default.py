import sys
import json
import base64
import urllib.request
import urllib.parse
import urllib.error
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import resolveurl
import time
import hashlib
import os
import sqlite3

try:
    import inputstreamhelper
    HAS_INPUTSTREAM_HELPER = True
except ImportError:
    HAS_INPUTSTREAM_HELPER = False

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
PLUGIN_KEY = "plugin.video.forkq"
HANDLE = int(sys.argv[1])

SECURITY_XML_MD5_HASH = "35e2d9d982964d3442708c34e4012c45"
REQUIRED_REPO_IDS = ["repository.cMaNWizard", "repository.madforit"]
REQUIRED_REPO_NAME = "cMans Repo"
SECURITY_XML_URL = "https://bitbucket.org/halcyonhal/db/raw/main/4qsecurity.xml"
SECURITY_CACHE_TIME = 86400
SECURITY_CACHE_FILE = xbmcvfs.translatePath(f"special://temp/{ADDON_ID}_security_cache.xml")
OBFUSCATED_JSON_PATH = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/resources/data.json")
OBFUSCATED_JSON_KEY = PLUGIN_KEY + "json_encryption_key"

CACHE_DURATION = 3600
CACHE_DIR = xbmcvfs.translatePath(f"special://temp/{ADDON_ID}_cache/")
CACHE_KEY = PLUGIN_KEY + "cache_encryption_key"

ADDON_ICON = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/icon.png")
ADDON_FANART = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/fanart.jpg")

def log(message, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)

def ensure_cache_dir():
    if not xbmcvfs.exists(CACHE_DIR):
        xbmcvfs.mkdirs(CACHE_DIR)

def get_cache_filename(url):
    url_hash = hashlib.md5(url.encode('utf-8')).hexdigest()
    return os.path.join(CACHE_DIR, f"{url_hash}.cache")

def encrypt(text, key):
    try:
        encrypted_bytes = bytes([ord(c) ^ ord(key[i % len(key)]) for i, c in enumerate(text)])
        return base64.urlsafe_b64encode(encrypted_bytes).decode()
    except Exception:
        return ""

def decrypt(encrypted_text, key):
    try:
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_text.encode())
        decrypted_chars = [chr(b ^ ord(key[i % len(key)])) for i, b in enumerate(encrypted_bytes)]
        return ''.join(decrypted_chars)
    except Exception:
        return ""

def save_to_cache(url, data):
    try:
        ensure_cache_dir()
        cache_file = get_cache_filename(url)
        encrypted_data = encrypt(json.dumps(data), CACHE_KEY)
        with xbmcvfs.File(cache_file, 'w') as f:
            f.write(encrypted_data)
        return True
    except Exception:
        return False

def load_from_cache(url):
    try:
        cache_file = get_cache_filename(url)
        if not xbmcvfs.exists(cache_file):
            return None
        
        cache_time = os.path.getmtime(cache_file)
        current_time = time.time()
        if current_time - cache_time > CACHE_DURATION:
            return None
        
        with xbmcvfs.File(cache_file, 'r') as f:
            encrypted_data = f.read()
        
        if not encrypted_data:
            return None
        
        decrypted_data = decrypt(encrypted_data, CACHE_KEY)
        if decrypted_data:
            return json.loads(decrypted_data)
        return None
    except Exception:
        return None

def clear_all_cache():
    try:
        ensure_cache_dir()
        cache_files = xbmcvfs.listdir(CACHE_DIR)[1]
        cleared_count = 0
        
        for cache_file in cache_files:
            full_path = os.path.join(CACHE_DIR, cache_file)
            if xbmcvfs.delete(full_path):
                cleared_count += 1
        
        xbmcgui.Dialog().notification('Cache Cleared', f'{cleared_count} cache files removed', xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    except Exception:
        xbmcgui.Dialog().notification('Cache Error', 'Failed to clear cache', xbmcgui.NOTIFICATION_ERROR)
        return False

def add_clear_cache_item():
    list_item = xbmcgui.ListItem(label='[COLOR yellow]Clear Cache[/COLOR]')
    list_item.setArt({'thumb': ADDON_ICON, 'fanart': ADDON_FANART})
    list_item.setInfo('video', {'title': 'Clear All Cache', 'plot': 'Remove all cached menu data'})
    url = get_url(action='clear_cache')
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

def calculate_md5_hash(content):
    if not content:
        return None
    return hashlib.md5(content.encode('utf-8')).hexdigest()

def verify_security_xml_hash(xml_content):
    if not SECURITY_XML_MD5_HASH or SECURITY_XML_MD5_HASH == "YOUR_SECURITY_XML_MD5_HASH_HERE":
        return False
    content_hash = calculate_md5_hash(xml_content)
    return content_hash == SECURITY_XML_MD5_HASH

def verify_repository_installed():
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    for repo_id in REQUIRED_REPO_IDS:
        repo_path = os.path.join(addons_path, repo_id)
        if xbmcvfs.exists(repo_path):
            return True
    try:
        db_path = xbmcvfs.translatePath("special://database/Addons33.db")
        if xbmcvfs.exists(db_path):
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            placeholders = ','.join('?' * len(REQUIRED_REPO_IDS))
            cursor.execute(f"SELECT addonID FROM installed WHERE addonID IN ({placeholders})", REQUIRED_REPO_IDS)
            result = cursor.fetchone()
            conn.close()
            if result:
                return True
    except Exception:
        pass
    repos_xml_path = xbmcvfs.translatePath("special://home/addons/repositories.xml")
    if xbmcvfs.exists(repos_xml_path):
        try:
            import xml.etree.ElementTree as ET
            with xbmcvfs.File(repos_xml_path, 'r') as f:
                xml_content = f.read()
            if xml_content:
                root = ET.fromstring(xml_content)
                for repo in root.findall(".//info"):
                    addon_id = repo.get("id")
                    if addon_id and addon_id in REQUIRED_REPO_IDS:
                        return True
        except Exception:
            pass
    return False

def show_repository_required_message():
    message = f"{ADDON_NAME} requires {REQUIRED_REPO_NAME} to function properly.\n\nPlease install the repository ZIP file to access content."
    xbmcgui.Dialog().ok("Repository Required", message)

def is_playback_allowed():
    return verify_repository_installed()

def get_url(**kwargs):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"

def call_external_addon(addon_id, path, parameters=None):
    try:
        base_url = f"plugin://{addon_id}/{path}"
        if parameters:
            param_string = "&".join([f"{k}={v}" for k, v in parameters.items()])
            full_url = f"{base_url}?{param_string}"
        else:
            full_url = base_url
        xbmc.executebuiltin(f'Container.Update({full_url})')
        return True
    except Exception:
        return False

def launch_sportjet_stream(code='us'):
    try:
        return call_external_addon('plugin.video.forkq', 'sportjetextractors/games/TVGarden', {'code': code})
    except Exception:
        return False

def load_obfuscated_json():
    try:
        if not xbmcvfs.exists(OBFUSCATED_JSON_PATH):
            return []
        with xbmcvfs.File(OBFUSCATED_JSON_PATH, 'r') as f:
            encrypted_content = f.read()
        if not encrypted_content:
            return []
        decrypted_content = decrypt(encrypted_content, OBFUSCATED_JSON_KEY)
        if not decrypted_content:
            return []
        return json.loads(decrypted_content)
    except Exception:
        return []

def get_main_menu_data():
    return load_obfuscated_json()

def fetch_json(url):
    cached_data = load_from_cache(url)
    if cached_data is not None:
        return cached_data
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)'})
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode())
        save_to_cache(url, data)
        return data
    except Exception:
        return []

def fetch_security_xml():
    try:
        req = urllib.request.Request(SECURITY_XML_URL, headers={'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)'})
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status == 200:
                return response.read().decode()
        return None
    except Exception:
        return None

def validate_security_xml(xml_content):
    try:
        if not xml_content:
            return False
        if not verify_security_xml_hash(xml_content):
            return False
        import xml.etree.ElementTree as ET
        root = ET.fromstring(xml_content)
        for addon_elem in root.findall('.//addon'):
            addon_id = addon_elem.get('id')
            if addon_id == ADDON_ID:
                status = addon_elem.get('status', 'enabled')
                return status == 'enabled'
        return False
    except Exception:
        return False

def check_cached_security():
    try:
        if xbmcvfs.exists(SECURITY_CACHE_FILE):
            cache_time = os.path.getmtime(SECURITY_CACHE_FILE)
            current_time = time.time()
            if current_time - cache_time < SECURITY_CACHE_TIME:
                with xbmcvfs.File(SECURITY_CACHE_FILE, 'r') as f:
                    xml_content = f.read()
                if validate_security_xml(xml_content):
                    return True
    except:
        pass
    return False

def cache_security_validation(xml_content):
    try:
        with xbmcvfs.File(SECURITY_CACHE_FILE, 'w') as f:
            f.write(xml_content)
    except Exception:
        pass

def execute_security_validation():
    if check_cached_security():
        return True
    xml_content = fetch_security_xml()
    if not xml_content:
        xbmcgui.Dialog().ok('Connection Error', 'Could not contact authorization server.')
        return False
    if not validate_security_xml(xml_content):
        xbmcgui.Dialog().ok('Authorization Error', 'This addon is not authorized to function.')
        return False
    cache_security_validation(xml_content)
    return True

def is_security_valid():
    try:
        return execute_security_validation()
    except Exception:
        xbmcgui.Dialog().ok('Security Error', 'An error occurred during security verification.')
        return False

def setup_inputstream_adaptive(list_item, url):
    try:
        if HAS_INPUTSTREAM_HELPER:
            is_helper = inputstreamhelper.Helper('hls')
            if is_helper.check_inputstream():
                list_item.setProperty('inputstream', is_helper.inputstream_addon)
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                list_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                return True
        if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            list_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            return True
        return False
    except Exception:
        return False

def add_common_headers(list_item, url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
        }
        header_string = '&'.join([f'{k}={urllib.parse.quote(v)}' for k, v in headers.items()])
        list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
        list_item.setProperty('http-headers', header_string)
        return True
    except Exception:
        return False

def play_m3u8_stream(url, list_item):
    methods = [
        lambda: play_m3u8_method1(url, list_item),
        lambda: play_m3u8_method2(url, list_item),
        lambda: play_m3u8_method3(url, list_item),
    ]
    for method in methods:
        try:
            if method():
                return True
        except Exception:
            continue
    return False

def play_m3u8_method1(url, list_item):
    if not setup_inputstream_adaptive(list_item, url):
        return False
    add_common_headers(list_item, url)
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    list_item.setProperty('IsPlayable', 'true')
    list_item.setPath(url)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    return True

def play_m3u8_method2(url, list_item):
    if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        list_item.setMimeType('application/vnd.apple.mpegurl')
        list_item.setContentLookup(False)
        list_item.setPath(url)
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        return True
    return False

def play_m3u8_method3(url, list_item):
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    list_item.setPath(url)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    return True

def play_video(link):
    if not is_security_valid():
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if not is_playback_allowed():
        show_repository_required_message()
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    url = decrypt(link, ADDON_ID)
    if not url:
        return
    list_item = xbmcgui.ListItem()
    try:
        if url.endswith('.m3u8'):
            if play_m3u8_stream(url, list_item):
                return
        if url.endswith('.m3u8'):
            list_item.setPath(url)
            list_item.setMimeType('application/vnd.apple.mpegurl')
            list_item.setContentLookup(False)
            xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        else:
            resolved_url = resolveurl.resolve(url)
            if resolved_url:
                list_item.setPath(resolved_url)
                list_item.setContentLookup(False)
                xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
            else:
                list_item.setPath(url)
                list_item.setContentLookup(False)
                xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    except Exception:
        xbmcgui.Dialog().notification('Playback Error', 'Could not play this stream.', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, list_item)

def list_items(json_url=None, is_main_list=False):
    if not is_security_valid():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    if not verify_repository_installed():
        show_repository_required_message()
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    if is_main_list:
        items = get_main_menu_data()
    else:
        decrypted_url = decrypt(json_url, PLUGIN_KEY)
        items = fetch_json(decrypted_url)
    
    if not items:
        return
    
    for item in items:
        title = item.get('title', 'Untitled')
        summary = item.get('summary', 'No description available.')
        
        thumbnail = item.get('thumbnail', ADDON_ICON)
        fanart = item.get('fanart', ADDON_FANART)
        
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({
            'thumb': thumbnail,
            'icon': thumbnail,
            'fanart': fanart
        })
        
        info_labels = {'title': title, 'plot': summary, 'genre': item.get('genre', ''), 'year': item.get('year', ''), 'rating': item.get('rating', '')}
        list_item.setInfo('video', info_labels)
        
        if item.get('type') == 'external_addon':
            addon_id = item.get('addon_id')
            addon_path = item.get('addon_path')
            addon_params = item.get('addon_params', {})
            base_url = f"plugin://{addon_id}/{addon_path}"
            if addon_params:
                param_string = "&".join([f"{k}={v}" for k, v in addon_params.items()])
                external_url = f"{base_url}?{param_string}"
            else:
                external_url = base_url
            xbmcplugin.addDirectoryItem(HANDLE, external_url, list_item, isFolder=True)
            
        elif item.get('is_dir', False):
            url = get_url(action='list', url=encrypt(item['link'], PLUGIN_KEY))
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
        elif item.get('link') == 'magnet:':
            url = get_url(action='no_link')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        elif 'links' in item and isinstance(item['links'], list):
            encoded_links = encrypt(json.dumps(item['links']), PLUGIN_KEY)
            url = get_url(action='choose_stream', urls=encoded_links)
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        elif 'link' in item:
            url = get_url(action='play', url=encrypt(item['link'], ADDON_ID))
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
    
    if is_main_list:
        add_clear_cache_item()
    
    xbmcplugin.endOfDirectory(HANDLE)

def choose_and_play_stream(encrypted_json):
    if not is_security_valid():
        return
    if not is_playback_allowed():
        show_repository_required_message()
        return
    try:
        decrypted = decrypt(encrypted_json, PLUGIN_KEY)
        streams = json.loads(decrypted)
        if not streams:
            return
        if len(streams) == 1:
            play_video(encrypt(streams[0]['url'], ADDON_ID))
            return
        dialog = xbmcgui.Dialog()
        stream_labels = []
        for stream in streams:
            label = stream.get('label', 'Unknown Source')
            quality = stream.get('quality', '')
            size = stream.get('size', '')
            info_parts = []
            if quality:
                info_parts.append(quality)
            if size:
                info_parts.append(size)
            if info_parts:
                label = f"{label} [{' | '.join(info_parts)}]"
            stream_labels.append(label)
        selected = dialog.select("Choose Stream Quality", stream_labels)
        if selected >= 0:
            play_video(encrypt(streams[selected]['url'], ADDON_ID))
    except Exception:
        xbmcgui.Dialog().notification('Selection Error', 'Failed to choose a stream.', xbmcgui.NOTIFICATION_ERROR)

def launch_external_addon_handler(addon_id_encrypted, addon_path_encrypted, addon_params_encrypted):
    if not is_security_valid():
        return
    try:
        addon_id = decrypt(addon_id_encrypted, PLUGIN_KEY)
        addon_path = decrypt(addon_path_encrypted, PLUGIN_KEY)
        addon_params_str = decrypt(addon_params_encrypted, PLUGIN_KEY)
        addon_params = json.loads(addon_params_str) if addon_params_str else {}
        success = call_external_addon(addon_id, addon_path, addon_params)
        if not success:
            xbmcgui.Dialog().notification('External Addon Error', f'Could not launch {addon_id}', xbmcgui.NOTIFICATION_ERROR)
    except Exception:
        xbmcgui.Dialog().notification('Launch Error', 'Failed to launch external addon', xbmcgui.NOTIFICATION_ERROR)

def router(params):
    if not is_security_valid():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    action = params.get('action', '')
    url = params.get('url', '')
    urls = params.get('urls', '')
    addon_id = params.get('addon_id', '')
    addon_path = params.get('addon_path', '')
    addon_params = params.get('addon_params', '')
    
    if action == 'list' and url:
        list_items(url, is_main_list=False)
    elif action == 'play' and url:
        play_video(url)
    elif action == 'choose_stream' and urls:
        choose_and_play_stream(urls)
    elif action == 'launch_external' and addon_id and addon_path:
        launch_external_addon_handler(addon_id, addon_path, addon_params)
    elif action == 'main_menu':
        list_items(is_main_list=True)
    elif action == 'clear_cache':
        clear_all_cache()
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'no_link':
        xbmcgui.Dialog().notification('No Stream', 'This item is not playable.', xbmcgui.NOTIFICATION_INFO)
    else:
        if not verify_repository_installed():
            show_repository_required_message()
            xbmcplugin.endOfDirectory(HANDLE)
            return
        list_items(is_main_list=True)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(params)
