"""
EasyFlix Kodi Addon Main Module

Handles directory listing and stream playback using remote JSON configuration.
"""

import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc
import sys
import json
import urllib.request
import urllib.parse
import resolveurl

EXPECTED_ID = "plugin.video.easyflix"
DEFAULT_URL = 'https://bitbucket.org/halcyonhal/easy_neo/raw/main/easy.json'

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])

def check_addon_id():
    """Ensure the addon ID matches the expected value."""
    actual_id = ADDON.getAddonInfo("id")
    if actual_id != EXPECTED_ID:
        xbmcgui.Dialog().ok("Error", "Addon ID Mismatch!")
        raise SystemExit

def get_remote_json(url):
    """Download and parse JSON data from a remote URL."""
    try:
        with urllib.request.urlopen(url) as response:
            return json.loads(response.read())
    except Exception as e:
        xbmcgui.Dialog().ok("Network Error", f"Failed to load content:\n{e}")
        return []

def make_art(entry):
    """Create an art dictionary for a list item from a JSON entry."""
    return {
        'thumb': entry.get('thumbnail', ''),
        'fanart': entry.get('fanart', '')
    }

def list_directory(url):
    """List the contents of a directory from a remote JSON."""
    items = get_remote_json(url)
    for entry in items:
        entry_type = entry.get("type")
        if entry_type == "folder":
            list_item = xbmcgui.ListItem(label=entry.get("name", "Folder"))
            list_item.setArt(make_art(entry))
            folder_url = entry.get("url", "")
            if not folder_url:
                continue
            folder_query = f"{sys.argv[0]}?action=list_directory&url={urllib.parse.quote(folder_url)}"
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=folder_query, listitem=list_item, isFolder=True)
        elif entry_type == "movie":
            list_item = xbmcgui.ListItem(label=entry.get("item", "Movie"))
            list_item.setArt(make_art(entry))
            movie_data = json.dumps(entry, separators=(',', ':'))
            encoded_movie = urllib.parse.quote(movie_data)
            url = f"{sys.argv[0]}?action=select_stream&data={encoded_movie}"
            list_item.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def select_stream(encoded_movie_data):
    """Prompt the user to select a stream and start playback."""
    try:
        movie = json.loads(urllib.parse.unquote(encoded_movie_data))
    except Exception:
        xbmcgui.Dialog().ok("Error", "Invalid movie data.")
        return

    links = movie.get("link", [])
    if not links:
        xbmcgui.Dialog().ok("Playback Error", "No available links.")
        return

    # If only one stream link, play immediately
    if len(links) == 1:
        stream_url = links[0].get("url", "")
    else:
        labels = [l.get("label", f"Link {i+1}") for i, l in enumerate(links)]
        choice = xbmcgui.Dialog().select(f"Select A Stream For: {movie.get('item', 'Unknown')}", labels)
        if choice == -1:
            return
        stream_url = links[choice].get("url", "")

    if not stream_url:
        xbmcgui.Dialog().ok("Playback Error", "Invalid stream URL.")
        return

    # Check if it's a direct .m3u8 stream
    if stream_url.endswith(".m3u8"):
        final_url = stream_url
    else:
        # Use resolveurl for other links
        final_url = resolveurl.resolve(stream_url)
        if not final_url:
            xbmcgui.Dialog().ok("Playback Error", "Unable to resolve link.")
            return

    play_item = xbmcgui.ListItem(path=final_url)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)

def router(paramstring):
    """Route incoming plugin actions."""
    import urllib.parse as urlparse
    params = dict(urlparse.parse_qsl(paramstring))
    action = params.get("action")
    if action == "list_directory":
        url = params.get("url", DEFAULT_URL)
        list_directory(url)
    elif action == "select_stream":
        data = params.get("data")
        if data:
            select_stream(data)
    else:
        list_directory(DEFAULT_URL)

if __name__ == "__main__":
    check_addon_id()
    if len(sys.argv) > 2:
        router(sys.argv[2][1:])
    else:
        list_directory(DEFAULT_URL)

