import os
import sys
import json
import base64
import urllib.request
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmcaddon
import resolveurl

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
handle = int(sys.argv[1])

def get_url(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)

def fetch_json(url):
    try:
        with urllib.request.urlopen(url) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to load content: {e}', xbmcgui.NOTIFICATION_ERROR)
        return []

def encrypt(text: str, key: str) -> str:
    encrypted_bytes = bytes([ord(c) ^ ord(key[i % len(key)]) for i, c in enumerate(text)])
    return base64.urlsafe_b64encode(encrypted_bytes).decode()

def decrypt(encrypted_text: str, key: str) -> str:
    encrypted_bytes = base64.urlsafe_b64decode(encrypted_text.encode())
    decrypted_chars = [chr(b ^ ord(key[i % len(key)])) for i, b in enumerate(encrypted_bytes)]
    return ''.join(decrypted_chars)

def list_items(encrypted_json_url):
    json_url = decrypt(encrypted_json_url, addon_id)
    items = fetch_json(json_url)

    for item in items:
        title = item.get('title', 'No Title')
        thumb = item.get('thumbnail', '')
        fanart = item.get('fanart', '')
        link = item.get('link', '')
        is_dir = item.get('is_dir', False)

        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'thumb': thumb, 'fanart': fanart})

        if is_dir:
            url = get_url(action='list', url=encrypt(link, addon_id))
            xbmcplugin.addDirectoryItem(handle, url, list_item, True)
        else:
            url = get_url(action='play', url=encrypt(link, addon_id))
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, url, list_item, False)

    xbmcplugin.endOfDirectory(handle)

def play_video(encrypted_link):
    url = decrypt(encrypted_link, addon_id)
    list_item = xbmcgui.ListItem(path=url)
    list_item.setProperty('IsPlayable', 'true')

    if url.endswith('.m3u8'):
        list_item.setMimeType('application/vnd.apple.mpegurl')
        xbmcplugin.setResolvedUrl(handle, True, list_item)
    elif url.startswith('magnet:'):
        resolved = resolveurl.resolve(url)
        if resolved:
            list_item.setPath(resolved)
            xbmcplugin.setResolvedUrl(handle, True, list_item)
        else:
            xbmcgui.Dialog().notification('Magnet Error', 'Unable to resolve magnet link', xbmcgui.NOTIFICATION_ERROR)
    else:
        resolved = resolveurl.resolve(url)
        if resolved:
            list_item.setPath(resolved)
            xbmcplugin.setResolvedUrl(handle, True, list_item)
        else:
            xbmcgui.Dialog().notification('Playback Error', 'Unable to resolve link', xbmcgui.NOTIFICATION_ERROR)

def router(params):
    action = params.get('action')
    url = params.get('url')

    if action == 'list' and url:
        list_items(url)
    elif action == 'play' and url:
        play_video(url)
    else:
        default_url = encrypt('https://cmanbuildsxyz.com/dude/neo.json', addon_id)
        list_items(default_url)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(params)

