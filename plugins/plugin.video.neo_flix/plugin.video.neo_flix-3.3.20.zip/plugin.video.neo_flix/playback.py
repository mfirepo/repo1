import time
import urllib.request
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmc
import xbmcvfs
import resolveurl
import re
import json
from config import ADDON_ID, PLUGIN_KEY, HANDLE, ADDON_NAME, ADDON_VERSION
from utils import log
from encryption import decrypt, encrypt
from security import SecurityManager

class PlaybackManager:
    def __init__(self):
        self.security_manager = SecurityManager()
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ]
    
    def get_rotated_user_agent(self):
        return self.user_agents[int(time.time()) % len(self.user_agents)]
    
    def setup_robust_inputstream(self, list_item, url):
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        list_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        list_item.setProperty('inputstream.adaptive.license_flags', 'persistent_storage')
        list_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        list_item.setProperty('inputstream.adaptive.connection_timeout', '60')
        list_item.setProperty('inputstream.adaptive.manifest_timeout', '60')
        list_item.setProperty('inputstream.adaptive.live_delay', '3')
        list_item.setProperty('inputstream.adaptive.max_bandwidth', '12000000')
        list_item.setProperty('inputstream.adaptive.min_bandwidth', '500000')
        list_item.setProperty('inputstream.adaptive.max_resolution', '1080p')
        list_item.setProperty('inputstream.adaptive.network_caching', '20000')
        list_item.setProperty('inputstream.adaptive.segment_download_retries', '10')
        list_item.setProperty('inputstream.adaptive.segment_download_timeout', '45')
        list_item.setProperty('inputstream.adaptive.segment_download_retry_wait', '5')
        list_item.setProperty('inputstream.adaptive.max_segment_count', '50')
        list_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
        list_item.setProperty('inputstream.adaptive.ignore_manifest_segment_timestamps', 'true')
        return True
    
    def extract_m3u8_segments(self, m3u8_content):
        segments = []
        lines = m3u8_content.split('\n')
        for line in lines:
            if line.startswith('http') and '.ts' in line:
                segments.append(line.strip())
        return segments
    
    def get_refreshed_stream(self, base_url, max_retries=5):
        for attempt in range(max_retries):
            try:
                timestamp = int(time.time())
                user_agent = self.get_rotated_user_agent()
                
                refreshed_url = f"{base_url}{'&' if '?' in base_url else '?'}_t={timestamp}&_={timestamp}"
                
                req = urllib.request.Request(refreshed_url, headers={
                    'User-Agent': user_agent,
                    'Accept': '*/*',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Accept-Encoding': 'identity',
                    'Connection': 'keep-alive',
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                })
                
                with urllib.request.urlopen(req, timeout=15) as response:
                    if response.status == 200:
                        content = response.read().decode('utf-8')
                        if '#EXTM3U' in content:
                            log(f"Stream refresh successful - attempt {attempt + 1}")
                            return refreshed_url
                        else:
                            log(f"Invalid M3U8 content received")
                            
            except Exception as e:
                log(f"Stream refresh attempt {attempt + 1} failed: {str(e)}")
                time.sleep(3)
        
        log("All stream refresh attempts failed")
        return base_url
    
    def check_stream_health(self, url):
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': self.get_rotated_user_agent(),
                'Accept': '*/*',
                'Cache-Control': 'no-cache'
            })
            with urllib.request.urlopen(req, timeout=15) as response:
                content = response.read().decode('utf-8')
                if '#EXTM3U' in content and '#EXTINF' in content:
                    segments = self.extract_m3u8_segments(content)
                    log(f"Stream health check passed - {len(segments)} segments found")
                    return True
            return False
        except Exception as e:
            log(f"Stream health check failed: {str(e)}")
            return False
    
    def create_robust_headers(self):
        user_agent = self.get_rotated_user_agent()
        return {
            'User-Agent': user_agent,
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'identity',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        }
    
    def play_robust_m3u8(self, url, list_item):
        list_item.setMimeType('application/vnd.apple.mpegurl')
        list_item.setContentLookup(False)
        list_item.setProperty('IsPlayable', 'true')
        
        self.setup_robust_inputstream(list_item, url)
        
        headers = self.create_robust_headers()
        header_string = '&'.join([f'{k}={urllib.parse.quote(v)}' for k, v in headers.items()])
        list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
        list_item.setProperty('http-headers', header_string)
        
        list_item.setPath(url)
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        return True
    
    def monitor_playback(self):
        player = xbmc.Player()
        monitor = xbmc.Monitor()
        last_check = time.time()
        
        while not monitor.abortRequested() and player.isPlaying():
            current_time = time.time()
            if current_time - last_check > 30:
                try:
                    playing_file = player.getPlayingFile()
                    if playing_file and '.m3u8' in playing_file:
                        if not self.check_stream_health(playing_file):
                            log("Stream health check failed during playback")
                            return False
                    last_check = current_time
                except:
                    pass
            if monitor.waitForAbort(5):
                break
        return True
    
    def play_video_with_recovery(self, link):
        if not self.security_manager.is_security_valid():
            return
            
        original_url = decrypt(link, ADDON_ID)
        if not original_url:
            return
            
        max_attempts = 1
        for attempt in range(max_attempts):
            try:
                list_item = xbmcgui.ListItem()
                current_url = original_url
                
                if attempt > 0:
                    current_url = self.get_refreshed_stream(original_url)
                    log(f"Playback attempt {attempt + 1} with refreshed URL")
                
                if current_url.endswith('.m3u8'):
                    if self.play_robust_m3u8(current_url, list_item):
                        if self.monitor_playback():
                            log("Playback completed successfully")
                            return True
                        else:
                            log("Playback monitoring detected stream failure")
                            continue
                else:
                    resolved_url = resolveurl.resolve(current_url)
                    if resolved_url:
                        list_item.setPath(resolved_url)
                    else:
                        list_item.setPath(current_url)
                        
                    list_item.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
                    return True
                    
            except Exception as e:
                log(f"Playback attempt {attempt + 1} failed: {str(e)}")
                if attempt < max_attempts - 1:
                    time.sleep(5)
        
        xbmcgui.Dialog().notification('Playback Error', 'Could not establish stable stream connection', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    
    def play_video(self, link):
        if not self.security_manager.is_security_valid():
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        if not self.security_manager.is_playback_allowed():
            self.security_manager.show_repository_required_message()
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
            
        self.play_video_with_recovery(link)

    def show_stream_selection_dialog(self, streams):
        """Show a dialog box for the user to choose from available streams"""
        # Create list of stream labels for the dialog (no sorting or quality indicators)
        stream_labels = []
        for stream in streams:
            label = stream.get('label', 'Unknown Stream')
            stream_labels.append(label)
        
        # Show selection dialog
        dialog = xbmcgui.Dialog()
        selected_index = dialog.select('Choose Stream', stream_labels)
        
        if selected_index >= 0:
            # User selected a stream
            selected_stream = streams[selected_index]
            log(f"User selected stream: {selected_stream.get('label', 'Unknown')}")
            self.play_video(encrypt(selected_stream['url'], ADDON_ID))
        else:
            # User cancelled the dialog
            log("User cancelled stream selection")
            xbmcgui.Dialog().notification('Selection Cancelled', 'No stream was selected.', xbmcgui.NOTIFICATION_INFO)
    
    def choose_and_play_stream(self, encrypted_json):
        """Show dialog box for stream selection when multiple streams available"""
        if not self.security_manager.is_security_valid():
            return
        if not self.security_manager.is_playback_allowed():
            self.security_manager.show_repository_required_message()
            return
        try:
            decrypted = decrypt(encrypted_json, PLUGIN_KEY)
            streams = json.loads(decrypted)
            if not streams:
                xbmcgui.Dialog().notification('No Streams', 'No streams available', xbmcgui.NOTIFICATION_ERROR)
                return
            
            # If only one stream available, play it automatically
            if len(streams) == 1:
                log("Only one stream available, playing it automatically")
                self.play_video(encrypt(streams[0]['url'], ADDON_ID))
            else:
                # Show dialog box for multiple streams
                log(f"Multiple streams available, showing selection dialog for {len(streams)} options")
                self.show_stream_selection_dialog(streams)
                
        except Exception as e:
            log(f"Stream selection error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Selection Error', 'Failed to choose a stream.', xbmcgui.NOTIFICATION_ERROR)
