import sys
import json
import base64
import urllib.request
import urllib.parse
import urllib.error
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import resolveurl
from typing import Dict, List, Optional, Any
import time
import hashlib

# Addon info
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
PLUGIN_KEY = "plugin.video.neo_flix"
DEFAULT_JSON_URL = "https://archive.org/download/neolist/neolist.json"
HANDLE = int(sys.argv[1])
CACHE_TIMEOUT = 3600  # 1 hour cache

def log(message: str, level=xbmc.LOGINFO) -> None:
    """Enhanced logging with version info"""
    xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)

def get_url(**kwargs: Dict[str, str]) -> str:
    """Generate a plugin URL with the given parameters"""
    return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"

def get_cache_key(url: str) -> str:
    """Generate a cache key from URL"""
    return hashlib.md5(url.encode()).hexdigest()

def get_cached_data(cache_key: str) -> Optional[Any]:
    """Retrieve data from cache if available and not expired"""
    cache_path = f"special://temp/{ADDON_ID}_{cache_key}.cache"
    try:
        if xbmcvfs.exists(cache_path):
            with xbmcvfs.File(cache_path, 'r') as f:
                cache_data = json.load(f)
            # Check if cache is still valid
            if time.time() - cache_data['timestamp'] < CACHE_TIMEOUT:
                return cache_data['data']
    except:
        pass  # If cache fails, we'll just fetch fresh data
    return None

def set_cached_data(cache_key: str, data: Any) -> None:
    """Store data in cache with timestamp"""
    cache_path = f"special://temp/{ADDON_ID}_{cache_key}.cache"
    try:
        cache_data = {
            'timestamp': time.time(),
            'data': data
        }
        with xbmcvfs.File(cache_path, 'w') as f:
            f.write(json.dumps(cache_data))
    except:
        log("Failed to write cache", xbmc.LOGWARNING)

def fetch_json(url: str, use_cache: bool = True) -> List[Dict]:
    """Fetch JSON data from URL with caching support"""
    cache_key = get_cache_key(url)
    
    # Try to get cached data first
    if use_cache:
        cached_data = get_cached_data(cache_key)
        if cached_data is not None:
            log(f"Using cached data for {url}")
            return cached_data
    
    # Fetch fresh data if no cache available
    try:
        req = urllib.request.Request(
            url,
            headers={'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)'}
        )
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode())
            
            # Cache the successful response
            if use_cache:
                set_cached_data(cache_key, data)
                
            return data
    except urllib.error.URLError as e:
        log(f"Failed to fetch JSON from {url}: {e}", xbmc.LOGERROR)
        # Return cached data even if expired as fallback
        if use_cache:
            cached_data = get_cached_data(cache_key)
            if cached_data is not None:
                log("Using expired cache as fallback")
                return cached_data['data']
        xbmcgui.Dialog().notification('Connection Error', 'Failed to fetch content. Check your internet.', xbmcgui.NOTIFICATION_ERROR)
    except json.JSONDecodeError as e:
        log(f"Invalid JSON from {url}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Data Error', 'Invalid content received from server.', xbmc.LOGNOTIFICATION_ERROR)
    except Exception as e:
        log(f"Unexpected error fetching JSON: {e}", xbmc.LOGERROR)
    
    return []

def encrypt(text: str, key: str) -> str:
    """Encrypt text using XOR cipher with key"""
    try:
        encrypted_bytes = bytes([ord(c) ^ ord(key[i % len(key)]) for i, c in enumerate(text)])
        return base64.urlsafe_b64encode(encrypted_bytes).decode()
    except Exception as e:
        log(f"Encryption failed: {e}", xbmc.LOGERROR)
        return ""

def decrypt(encrypted_text: str, key: str) -> str:
    """Decrypt text using XOR cipher with key"""
    try:
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_text.encode())
        decrypted_chars = [chr(b ^ ord(key[i % len(key)])) for i, b in enumerate(encrypted_bytes)]
        return ''.join(decrypted_chars)
    except Exception as e:
        log(f"Decryption failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Decryption Error', 'Failed to decode stream URL.', xbmcgui.NOTIFICATION_ERROR)
        return ""

def list_items(json_url: str) -> None:
    """List all items from the JSON data"""
    items = fetch_json(decrypt(json_url, ADDON_ID))
    if not items:
        xbmcgui.Dialog().notification('No Content', 'No items found in the list.', xbmcgui.NOTIFICATION_INFO)
        return

    for item in items:
        title = item.get('title', 'Untitled')
        summary = item.get('summary', 'No description available.')
        thumbnail = item.get('thumbnail', '')
        fanart = item.get('fanart', '')
        genre = item.get('genre', '')
        year = item.get('year', '')
        rating = item.get('rating', '')

        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'thumb': thumbnail, 'fanart': fanart})
        
        # Set additional info for better Kodi integration
        info_labels = {
            'title': title,
            'plot': summary,
            'genre': genre,
            'year': year,
            'rating': rating
        }
        list_item.setInfo('video', info_labels)

        if item.get('is_dir', False):
            url = get_url(action='list', url=encrypt(item['link'], PLUGIN_KEY))
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
        elif item.get('link') == 'magnet:':
            url = get_url(action='no_link')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        elif 'links' in item and isinstance(item['links'], list):
            encoded_links = encrypt(json.dumps(item['links']), PLUGIN_KEY)
            url = get_url(action='choose_stream', urls=encoded_links)
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        elif 'link' in item:
            url = get_url(action='play', url=encrypt(item['link'], ADDON_ID))
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
    
    # Add Clear Cache option at the bottom with lime color and custom art
    list_item = xbmcgui.ListItem(label='[COLOR lime]Clear Cache[/COLOR]')
    # Set thumbnail and fanart for the Clear Cache option
    list_item.setArt({
        'thumb': 'https://archive.org/download/iconlarge/iconlarge.png',
        'fanart': 'https://archive.org/download/fanart4k/fanart4k.jpg'
    })
    list_item.setInfo('video', {'title': 'Clear Cache', 'plot': 'Clear all cached data to free up space and resolve potential issues'})
    url = get_url(action='clear_cache')
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def play_video(link: str) -> None:
    """Play video from the provided link"""
    url = decrypt(link, ADDON_ID)
    if not url:
        return

    try:
        if url.endswith('.m3u8'):
            item = xbmcgui.ListItem(path=url)
            item.setMimeType('application/vnd.apple.mpegurl')
            item.setContentLookup(False)
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(HANDLE, True, item)
        else:
            resolved_url = resolveurl.resolve(url)
            
            if resolved_url:
                item = xbmcgui.ListItem(path=resolved_url)
                item.setContentLookup(False)
                xbmcplugin.setResolvedUrl(HANDLE, True, item)
            else:
                raise Exception("ResolveURL failed to resolve the URL")
    except Exception as e:
        log(f"Failed to resolve URL {url}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Playback Error', 'Could not play this stream.', xbmcgui.NOTIFICATION_ERROR)

def choose_and_play_stream(encrypted_json: str) -> None:
    """Let user choose from multiple stream options"""
    try:
        decrypted = decrypt(encrypted_json, PLUGIN_KEY)
        streams = json.loads(decrypted)
        if not streams:
            raise ValueError("No streams available")

        if len(streams) == 1:
            play_video(encrypt(streams[0]['url'], ADDON_ID))
            return

        # Create stream selection dialog
        dialog = xbmcgui.Dialog()
        stream_labels = []
        for stream in streams:
            label = stream.get('label', 'Unknown Source')
            quality = stream.get('quality', '')
            size = stream.get('size', '')
            
            # Format the label nicely
            info_parts = []
            if quality:
                info_parts.append(quality)
            if size:
                info_parts.append(size)
                
            if info_parts:
                label = f"{label} [{' | '.join(info_parts)}]"
                
            stream_labels.append(label)

        selected = dialog.select("Choose Stream Quality", stream_labels)
        
        if selected >= 0:
            play_video(encrypt(streams[selected]['url'], ADDON_ID))
    except Exception as e:
        log(f"Stream selection failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Selection Error', 'Failed to choose a stream.', xbmcgui.NOTIFICATION_ERROR)

def clear_cache() -> None:
    """Clear all cached data"""
    try:
        cache_files = xbmcvfs.listdir(f"special://temp/{ADDON_ID}_")[1]
        for file in cache_files:
            if file.startswith(f"{ADDON_ID}_") and file.endswith(".cache"):
                xbmcvfs.delete(f"special://temp/{file}")
        log("Cache cleared successfully")
        xbmcgui.Dialog().notification('Cache Cleared', 'All cached data has been removed.', xbmcgui.NOTIFICATION_INFO)
    except Exception as e:
        log(f"Failed to clear cache: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Cache Error', 'Failed to clear cache.', xbmcgui.NOTIFICATION_ERROR)

def router(params: Dict[str, str]) -> None:
    """Route the plugin actions"""
    action = params.get('action', '')
    url = params.get('url', '')
    urls = params.get('urls', '')
    
    # Additional actions
    if action == 'clear_cache':
        clear_cache()
    elif action == 'list' and url:
        list_items(url)
    elif action == 'play' and url:
        play_video(url)
    elif action == 'choose_stream' and urls:
        choose_and_play_stream(urls)
    elif action == 'no_link':
        xbmcgui.Dialog().notification('No Stream', 'This item is not playable.', xbmcgui.NOTIFICATION_INFO)
    else:
        default_url = encrypt(DEFAULT_JSON_URL, PLUGIN_KEY)
        list_items(default_url)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(params)
