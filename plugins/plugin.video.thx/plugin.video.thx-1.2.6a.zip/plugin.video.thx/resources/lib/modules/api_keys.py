# -*- coding: utf-8 -*-

import base64, sys
from six import ensure_text


def chk():
    return True;

tmdb_key = ensure_text(base64.b64decode(b'YjQyYjJhMGFmNDVjMmFiNDc1YjNlODhlM2JmYmM0N2Y=')) if chk() else ''
tvdb_key = ensure_text(base64.b64decode(b'UVkzTUVUMU1UU0ZBTkJYVw==')) if chk() else ''
omdb_key = ensure_text(base64.b64decode(b'OGI1Mjg3ODM=')) if chk() else ''
fanarttv_key = ensure_text(base64.b64decode(b'YzM0NjljMWNjOTQ2NWI5ZjFhMWE4NjJmZWVhOGI3NmI=')) if chk() else ''
yt_key = ensure_text(base64.b64decode(b'QUl6YVN5QllQTHFOYjlVb29EdnhFS2poRTFRelhZQzY5OHpFeWg0')) if chk() else ''
trakt_client_id = ensure_text(base64.b64decode(b'ZmYxMzMyMTgzMWFiNDZhMzQxMDhjZThiOGQ5YWRiYjEwNmI1ZWQ0NjBmODgzMDNlZWIwYjJkOTUzNGM2ZGM4Mw==')) if chk() else ''
trakt_secret = ensure_text(base64.b64decode(b'MmM1Y2M3MGE3YmI4YTAzMGUwOTE5MzgwM2U3NzM1NzljZjUyOTg1NTIxMGY0N2ZmMWY0YzUzZmVlYjRmMjA2Yw==')) if chk() else ''
orion_key = ensure_text(base64.b64decode(b'VFVKUERHTENFQkJSQUdSSlJQVkhNNk1DSFNGM1IyRjQ=')) if chk() else ''
