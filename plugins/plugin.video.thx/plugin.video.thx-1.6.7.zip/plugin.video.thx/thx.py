# -*- coding: utf-8 -*-

'''
    THX 1138 Add-on
'''

import xbmcgui
import xbmc
import xbmcaddon
import xbmcvfs
import os
import traceback

from sys import argv
from resources.lib.modules import router

# Define repository information
REQUIRED_REPO_IDS = [
    "repository.cMaNWizard",  # cMan's Repository ID
    "repository.madforit",  # Mad For It Repository ID
    #"repository.mfirepo"  # MFire Repository ID
]

REQUIRED_REPO_NAME = "cMans Repo"

def check_repository_installed():
    """
    Check if any of the required repositories are installed in Kodi.
    Returns True if found, False otherwise.
    """
    # Check through addons directory
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    
    # Look for each repository directory
    for repo_id in REQUIRED_REPO_IDS:
        repo_path = os.path.join(addons_path, repo_id)
        
        if xbmcvfs.exists(repo_path):
            xbmc.log(f"[THX 1138] Required repository found: {repo_id}", xbmc.LOGINFO)
            return True
    
    # Additional check: look for repository in database
    try:
        import sqlite3
        
        # Path to Kodi's database
        db_path = xbmcvfs.translatePath("special://database/Addons33.db")
        
        if xbmcvfs.exists(db_path):
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Query to check if any repository is installed
            placeholders = ','.join('?' * len(REQUIRED_REPO_IDS))
            cursor.execute(f"SELECT addonID FROM installed WHERE addonID IN ({placeholders})", REQUIRED_REPO_IDS)
            result = cursor.fetchone()
            
            conn.close()
            
            if result:
                xbmc.log(f"[THX 1138] Required repository found in database: {result[0]}", xbmc.LOGINFO)
                return True
    except Exception as e:
        xbmc.log(f"[THX 1138] Error checking database for repository: {e}", xbmc.LOGERROR)
    
    # Check repositories.xml file
    repos_xml_path = xbmcvfs.translatePath("special://home/addons/repositories.xml")
    
    if xbmcvfs.exists(repos_xml_path):
        try:
            import xml.etree.ElementTree as ET
            
            with xbmcvfs.File(repos_xml_path, 'r') as f:
                xml_content = f.read()
            
            if xml_content:
                root = ET.fromstring(xml_content)
                
                # Look for any of the required repository IDs in the XML
                for repo in root.findall(".//info"):
                    addon_id = repo.get("id")
                    if addon_id and addon_id in REQUIRED_REPO_IDS:
                        xbmc.log(f"[THX 1138] Required repository found in repositories.xml: {addon_id}", xbmc.LOGINFO)
                        return True
        except Exception as e:
            xbmc.log(f"[THX 1138] Error parsing repositories.xml: {e}", xbmc.LOGERROR)
    
    return False

# Check for required repository before proceeding
repo_installed = check_repository_installed()
if not repo_installed:
    # Show notification to user
    message = f"{REQUIRED_REPO_NAME} is required to run this addon.\n\nPlease install it from the repository ZIP file."
    
    xbmcgui.Dialog().ok("Repository Required", message)
    
    # Exit the addon
    exit()
else:
    xbmc.log("[THX 1138] Required repository found", xbmc.LOGINFO)

# If repository is installed, continue with normal routing
router.routing(argv[2])
